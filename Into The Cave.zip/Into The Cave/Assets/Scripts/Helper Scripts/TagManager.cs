public static class TagManager 
{
    public static string WALK_ANIMATION_PARAMETER = "Walk";
    public static string JUMP_ANIMATION_PARAMETER = "Jump";

    public static string OPEN_ANIMATION_NAME = "Open";

    public static string JUMP_BUTTON = "Jump";
    public static string PLAYER_TAG = "Player";
    public static string ENEMY_TAG = "Enemy";
    public static string GOAL_TAG = "Goal";
    
}
